package com.yash.yotaapi.domain;

import lombok.*;
import javax.persistence.*;

import org.springframework.security.core.GrantedAuthority;

import java.time.LocalDate;
import java.util.Collection;

@Entity
@Getter
@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "YOTA_USER")
public class YotaUser {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	private String name;
	
	private String emailId;
	
	private String username;

	private String password;

	private boolean enabled;

	// Assuming a field for account expiration date
	private LocalDate accountExpirationDate;
	// Assuming a field for account lock status
	private LocalDate credentialsExpirationDate;
	// Assuming a field for credentials expiration date
	private boolean accountLocked;

	@OneToOne
	@JoinColumn(name = "role_id", referencedColumnName = "id")
	private UserRole role;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "Trainig_id", referencedColumnName = "id")
	private Training Training;
	
	public Collection<? extends GrantedAuthority> getAuthorities(){
		return null;
	}

	public boolean isAccountNonExpired() {
		// Implement logic for account non-expiration
		// return true if the account never expires, or check expiration
		// date
		return true;
	}

	public boolean isAccountNonLocked() {
		// Implement logic for unlocked accounts
		// For example, return true if the account is not locked
		return true;
	}

	public boolean isCredentialsNonExpired() {
		// Implement logic for credentials non-expiration
		// For example, return true if credentials never expire, or check expiration
		// date
		return true;
	}

	public boolean isEnabled() {
		// Implement logic for enabled accounts
		// For example, return this.enabled; if 'enabled' is a field indicating account
		// status
		return this.enabled;
	}

	public YotaUser getUserRole() {
		// TODO Auto-generated method stub
		return null;
	}

}
